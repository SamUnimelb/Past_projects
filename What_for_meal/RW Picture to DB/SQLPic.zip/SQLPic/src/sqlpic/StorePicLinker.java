/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sqlpic;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class StorePicLinker {

    private Connection connect;
    private PreparedStatement preparedStatement;
    private ResultSet resultSet;
    private InputStream input;
    
    public StorePicLinker() {
        try {
            // this will load the MySQL driver, each DB has its own driver
            Class.forName("com.mysql.jdbc.Driver");
        } catch (Exception e) {
            e.printStackTrace();
        }//end try-catch
    }//end cons
    
    public boolean storePicture(String imgPath){
        try {
            // setup the connection with the DB.
            connect = DriverManager.getConnection("jdbc:mysql://localhost/sql_pic", "root", "123456");
            preparedStatement = connect.prepareStatement("SELECT foodDrinkID FROM foodimage;");
            resultSet = preparedStatement.executeQuery();
            
            int maxNewFoodDrinkID = 0;
            
            while(resultSet.next()){
                if(resultSet.getInt(1) > maxNewFoodDrinkID)
                    maxNewFoodDrinkID = resultSet.getInt(1);
            }//end if
             
            maxNewFoodDrinkID ++;
            
            input = new FileInputStream(imgPath);
            preparedStatement =connect.prepareStatement("insert into sql_pic.foodimage values(?,?)");
            preparedStatement.setInt(1,maxNewFoodDrinkID);
            preparedStatement.setBinaryStream(2, input, input.available());
            preparedStatement.executeUpdate();
            
            input.close();
            preparedStatement.close();
            resultSet.close();
            connect.close();
            return true;
        } catch (SQLException ex) {
            ex.printStackTrace();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(StorePicLinker.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(StorePicLinker.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }//end method

    public String readPicToMemory(int picID) {
        String loadingPath = "temp" + picID + ".jpg";
        try {
            // setup the connection with the DB.
            connect = DriverManager.getConnection("jdbc:mysql://localhost/sql_pic", "root", "123456");
                   preparedStatement = connect.prepareStatement("SELECT image FROM foodimage WHERE foodDrinkID = ?;");
            preparedStatement.setInt(1, picID);
            resultSet = preparedStatement.executeQuery();
            resultSet.next(); //将光标指向第一行
            input = resultSet.getBinaryStream(1);
            byte[] dataBlock = new byte[input.available()]; //新建保存图片数据的byte数组
            input.read(dataBlock);           
            
            OutputStream output = new FileOutputStream(loadingPath);
            output.write(dataBlock);
            output.flush();
            
            output.close();
            resultSet.close();
            preparedStatement.close();
            connect.close();        
        } catch (SQLException ex) {
            Logger.getLogger(StorePicLinker.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(StorePicLinker.class.getName()).log(Level.SEVERE, null, ex);
        }

        return loadingPath;
    }//end method
    
}//end class
